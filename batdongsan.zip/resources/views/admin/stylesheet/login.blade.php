{!! Html::style('admin/assets/img/favicon.png') !!}
{!! Html::style('admin/assets/css/bootstrap.min.css') !!}
{!! Html::style('admin/assets/css/font-awesome.min.css') !!}
{!! Html::style('http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,400,600,700,300') !!}
{!! Html::style('admin/assets/css/beyond.min.css') !!}
{!! Html::style('admin/assets/css/demo.min.css') !!}
{!! Html::style('admin/assets/css/animate.min.css') !!}