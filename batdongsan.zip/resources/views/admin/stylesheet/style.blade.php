<link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon">
<!--Basic Styles-->
{!! Html::style('admin/assets/css/bootstrap.min.css') !!}
{!! Html::style('admin/assets/css/font-awesome.min.css') !!}
{!! Html::style('admin/assets/css/weather-icons.min.css') !!}
{!! Html::style('admin/assets/css/beyond.min.css') !!}
{!! Html::style('admin/assets/css/demo.min.css') !!}
{!! Html::style('admin/assets/css/typicons.min.css') !!}
{!! Html::style('admin/assets/css/animate.min.css') !!}
{!! Html::style('http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,400,600,700,300') !!}
{!! Html::style('http://fonts.googleapis.com/css?family=Roboto:400,300') !!}