{!! Html::style('admin/assets/js/skins.min.js') !!}
{!! Html::style('admin/assets/js/jquery.min.js') !!}
{!! Html::style('admin/assets/js/bootstrap.min.js') !!}
{!! Html::style('admin/assets/js/slimscroll/jquery.slimscroll.min.js') !!}
{!! Html::style('admin/assets/js/assets/js/beyond.js') !!}
